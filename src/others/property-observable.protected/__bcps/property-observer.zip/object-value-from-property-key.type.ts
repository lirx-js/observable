export type IObjectValueFromPropertyKey<
  GObject,
  GPropertyKey extends PropertyKey,
> = GPropertyKey extends keyof GObject ? GObject[GPropertyKey] : unknown;
